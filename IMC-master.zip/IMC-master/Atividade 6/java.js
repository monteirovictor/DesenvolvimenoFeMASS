

function calcvol(){
	

	var largura=parseFloat(document.querySelector("#largura").value);
	var volume=parseFloat(document.querySelector("#volume").value);
	var altura=parseFloat(document.querySelector("#altura").value);
	
	

	var resultado=((largura*volume*altura)/1000);

	alert("O resultado em Litros" + resultado);

	document.querySelector("#resultado").value = resultado;

}