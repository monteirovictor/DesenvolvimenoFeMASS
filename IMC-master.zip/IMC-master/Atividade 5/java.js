

function media(){
	

	var nota1=parseFloat(document.querySelector("#nota1").value);
	var nota2=parseFloat(document.querySelector("#nota2").value);
	var nota3=parseFloat(document.querySelector("#nota3").value);
	var nota4=parseFloat(document.querySelector("#nota4").value);
	

	var resultado=((nota1+nota2+nota3+nota4)/4);

	alert(resultado);
	



if(resultado>=7){
alert("aprovado" + resultado);
}
else if(resultado>=4 && resultado<7){
alert("	Prova final " + resultado);
}
else if (resultado<4){
alert("reprovado " + resultado);	
}


	document.querySelector("#resultado").value = resultado;

}