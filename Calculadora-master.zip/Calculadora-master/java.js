function randomiconum(){
	document.querySelector("#num1").value=Math.floor(Math.random()*100);
	document.querySelector("#num2").value=Math.floor(Math.random()*100);
	
}

function soma(){
	var n1=parseFloat(document.querySelector("#num1").value);
	var n2=parseFloat(document.querySelector("#num2").value);
	var resultado=parseFloat(document.querySelector("#resultado").value);
	var result=n1+n2;

	if (resultado == result){
		document.querySelector("#banner").innerHTML="parabéns <a href='sub.html'>proximo</a>";
	} else {
		alert("Valor incorreto!");
		geranumero();
	}

	
	document.querySelector("#resultado").value=resultado;
	
}

function sub(){
	var n1=parseFloat(document.querySelector("#num1").value);
	var n2=parseFloat(document.querySelector("#num2").value);
	var resultado=parseFloat(document.querySelector("#resultado").value);
	var result=n1-n2;

	if (resultado == result){
		document.querySelector("#banner").innerHTML="parabéns <a href='mult.html'>proximo</a>";
	} else {
		alert("Valor incorreto!");
		geranumero();
	}

	
	document.querySelector("#resultado").value=resultado;
	
}

function multi(){
	var n1=parseFloat(document.querySelector("#num1").value);
	var n2=parseFloat(document.querySelector("#num2").value);
	var resultado=parseFloat(document.querySelector("#resultado").value);
	var result=n1*n2;

	if (resultado == result){
		document.querySelector("#banner").innerHTML="parabéns <a href='div.html'>proximo</a>";
	} else {
		alert("Valor incorreto!");
		geranumero();
	}

	
	document.querySelector("#resultado").value=resultado;
	
}