# Receitas

Repositório git cuja a inteção é aprender os conteúdos de HTML, css e Javascript 
nas aulas de desenvolvimento de sistemas II e facilitando o controle da professo-
ra ao ministrar as atividades em sala de aula. 
As tecnologias utilizadas são : o HTML5 e css .
